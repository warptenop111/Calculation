import java.awt.*;
import java.awt.event.*;
import java.applet.*;

public class Money extends Applet implements   WindowListener,ActionListener{
        Frame fr ;
		Panel p1,p2,p3,p4;
		Label l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13,l14,l15,l16,l17,l18,l19,l20,l21,l22,l23,l24;
		TextField t1,t2,t3,t4,t5,t6,t7,t8,t9,t10;
		Button  b1,b2;

		public static void main (String args[]){
	     	Money ob = new Money();
		    ob.init();
	    }
	    public void init(){ 		
	       fr   =new Frame ("�ӹǳ");	
		   p1 =new Panel();
	  	   p2 =new Panel();
		   p3 =new Panel();
		   p4 =new Panel();		

		   l1 =new Label ("    �������Ǩ�ͺ �ӹǹ�Թ����Ѻ�� Ẻ 1 ");
		   l2 =new Label ("�ӹǹ�Թ");
		   l3 =new Label ("�ҷ");	   	
           l4 =new Label ("ầ��  1,000 =");         l5 =new Label (" �");
		   l6 =new Label ("ầ��     500 =");		   l7 =new Label (" �");
		   l8 =new Label ("ầ��     100 =");		   l9 =new Label (" �");
	       l10 =new Label ("ầ��       50 =");		   l11 =new Label (" �");
		   l12 =new Label ("ầ��       20 =");		   l13 =new Label (" �");
		   l14 =new Label ("����­     10 =");		   l15 =new Label (" ����­");
		   l16 =new Label ("����­       5 =");		   l17 =new Label (" ����­");
		   l18 =new Label ("����­       2 =");		   l19 =new Label (" ����­");
		   l20 =new Label ("����­       1 =");		   l21 =new Label (" ����­");
		   l22 = new Label ("  ");    l23=new Label ("");     l24=new Label (""); 

		    t1 =new TextField(7);
			t2 =new TextField(5);
			t3 =new TextField(5);
			t4 =new TextField(5);
			t5 =new TextField(5);
			t6 =new TextField(5);
			t7 =new TextField(5);
			t8 =new TextField(5);
			t9 =new TextField(5);
			t10=new TextField(5);		

		   b1 =new Button("  ��ŧ  ");
		   b2 =new Button("  ������  ");	

           p1.add(l2);
		   p1.add(t1);
		   p1.add(l3);
		   p2.add(b1);
		   p2.add(b2);		
  
            p4.setLayout(new GridLayout(3,1));
			p4.add(l1);	p4.add(p1);  p4.add(p2);           
		   
		   p3.setLayout(new GridLayout(11,1));
		   p3.add(l23);  p3.add(l22);  p3.add(l24);
		   p3.add(l4);    p3.add(t2); p3.add(l5);
		   p3.add(l6);    p3.add(t3); p3.add(l7);
		   p3.add(l8);    p3.add(t4); p3.add(l9);
		   p3.add(l10);  p3.add(t5); p3.add(l11);
		   p3.add(l12);  p3.add(t6); p3.add(l13);
		   p3.add(l14);  p3.add(t7); p3.add(l15);
		   p3.add(l16);  p3.add(t8); p3.add(l17);
           p3.add(l18);  p3.add(t9); p3.add(l19);
		   p3.add(l20);  p3.add(t10); p3.add(l21);		   
		   
		   fr.setLayout(new GridLayout(1,1));		
		   fr.add(p4);				 
		   fr.add(p3);

		   Color B1 = new Color(249,249,177);
           fr.setBackground(B1);
		
		   b1.addActionListener(this);
		   b2.addActionListener(this);
		   fr.addWindowListener(this);
		   fr.setSize(500,250);
		   fr.setResizable(false);
		   fr.setVisible(true); 		
		}       
	    public void mouseClicked(MouseEvent e){}
		public void mouseEntered(MouseEvent e){}
        public void mouseExited(MouseEvent e){}
        public void mousePressed(MouseEvent e){}
        public void mouseReleased(MouseEvent e){}
	    public void actionPerformed(ActionEvent e){
			String x;
			x =t1.getText();
		    int tx = Integer.parseInt(x);            
			    				
           if (e.getSource() == b1)	{			   
				 t2.setText("0");		 t3.setText("0");			 t4.setText("0");
			 	 t5.setText("0");		 t6.setText("0");			 t7.setText("0");
				 t8.setText("0");		 t9.setText("0");			 t10.setText("0");
	   	            int sum=0;  			  	 
				     sum = tx/1000;		
                             t2.setText(""+sum);	
		             sum = tx/500;		
					         t3.setText(""+sum);	   
					 sum = tx/100;		
					         t4.setText(""+sum);	   
					 sum = tx/50;		
				             t5.setText(""+sum);	   
					 sum = tx/20;		
	                         t6.setText(""+sum);	   
					 sum = tx/10;		
	                         t7.setText(""+sum);	   
					 sum = tx/5;		
	                         t8.setText(""+sum);	   
					 sum = tx/2;		
	                         t9.setText(""+sum);	   
					 sum = tx/1;		
	                         t10.setText(""+sum);	   				
		}
		else if (e.getSource() == b2)	{
                 t1.setText("");		 t2.setText("");		 t3.setText("");		 t4.setText("");
			 	 t5.setText("");	  	 t6.setText("");		 t7.setText("");		 t8.setText("");
				 t9.setText("");		 t10.setText("");		
			 }
		}
		 public void windowOpened(WindowEvent e)	        {	}
		 public void windowClosed(WindowEvent e)   	    	{	}
		 public void windowClosing(WindowEvent e)	{
                              System.exit(0) ;		}
		 public void windowIconified(WindowEvent e)	        {	}
		 public void windowDeiconified(WindowEvent e)   	{	}
		 public void windowActivated(WindowEvent e)      	{	}
		 public void windowDeactivated(WindowEvent e)	    {	} 
}